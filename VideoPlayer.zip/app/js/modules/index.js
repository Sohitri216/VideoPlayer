'use strict';

module.exports = angular.module('NotePad.modules', [
    require('./public').name,
    require('./player').name
]);