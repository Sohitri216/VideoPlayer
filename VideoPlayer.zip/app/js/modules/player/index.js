'use strict';

module.exports = angular.module('NotePad.modules.player', ['ui.router'])
    .config(require('./router/router'))
    .filter('filter', require('./filter/filter'))
    .controller('PlayController', require('./controllers/PlayController'));