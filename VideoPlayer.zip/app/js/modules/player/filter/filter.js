'use strict';
module.exports = [
    function($sce) {
        return function(url) {
        	console.log('In filter:::',url);
          return $sce.trustAsResourceUrl(url);
        };
    }
];