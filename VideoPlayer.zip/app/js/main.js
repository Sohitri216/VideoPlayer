'use strict';

angular.module('NotePad', [
    'ui.router',
    'ui.bootstrap',
    'ngYoutubeEmbed',
    require('./modules').name
])