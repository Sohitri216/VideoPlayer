# NotePad

Frontend web app using Angular JS for users to perform CRUD operation on task management. 
### instruction

Requires [Node.js](https://nodejs.org/) v4+ to run.
To install node
```sh
$ curl -sL https://deb.nodesource.com/setup_6.x | sudo -E bash -
$ sudo apt-get install nodejs
$ sudo apt-get install build-essential
```
Clone the repo, Install the dependencies and devDependencies
```sh

$ npm install gulp -g
$ npm install bower -g
$ npm install && bower install
$ npm run watch
```
Browse the www folder in your localhost
